// Função para salvar os dados no localStorage
function salvarDados(nome, email, senha) {
    const usuario = {
      nome: nome,
      email: email,
      senha: senha,
    };
    
    localStorage.setItem('usuario', JSON.stringify(usuario));
  }
  // Função para recuperar os dados do localStorage
function recuperarDados() {
    const usuarioJSON = localStorage.getItem('usuario');
    if (usuarioJSON) {
      return JSON.parse(usuarioJSON);
    } else {
      return null;
    }
  }
// Função para validar o nome, email e senha
function validarDados(nome, email, senha) {
    // Implemente suas regras de validação aqui
    if (nome && email && senha) {
      // Exemplo de validação simples: verificar se o email contém '@'
      if (email.includes('@')) {
        return true;
      }
    }
    return false;
  }
  const nome = 'SeuNome';
  const email = 'seuemail@example.com';
  const senha = 'suasenha123';
  
  if (validarDados(nome, email, senha)) {
    salvarDados(nome, email, senha);
    console.log('Dados salvos com sucesso!');
  } else {
    console.log('Dados inválidos. Por favor, verifique as informações inseridas.');
  }
      
  
  